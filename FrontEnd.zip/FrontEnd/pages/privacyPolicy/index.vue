<template>
  <v-app>
    <p class="display-1 text-center mt-5">
      Privacy Policy
    </p>
    <v-container>
      <v-divider class="mb-5"></v-divider>
      <p>
        YallaDealz.com is totally committed to protecting the privacy of our
        site visitors and customers. The COBONE team members are customers
        themselves of other Internet sites and fully appreciate and respect the
        importance of privacy on the Internet. We will not disclose information
        about our customers to third parties except where it is part of
        providing a service to you - e.g. arranging for a product to be sent to
        you, carrying out credit and other security checks and for the purposes
        of customer research and profiling or where we have your express
        permission to do so.
      </p>
      <p class="title">Your Consent</p>
      <p>
        When you register to Cobone.com you will be providing a limited amount
        of information which we will store in a secure environment. The data
        that we hold for each customer is used in order to serve better content
        to each customer. Below is a list detailing what kind of information we
        store:
      </p>
      <ul>
        <li>Name and contact details</li>
        <li>Name and contact details</li>
        <li>Name and contact details</li>
        <li>Name and contact details</li>
      </ul>
    </v-container>
  </v-app>
</template>

<script>
export default {}
</script>

<style></style>
