<template>
  <v-app>
    <p class="display-1 text-center mt-5">
      Terms and Conditions
    </p>
    <v-container>
      <v-divider class="mb-5"></v-divider>

      <p class="title">Refunds</p>
      <p>
        We hate hidden terms and sneakiness just as much as you do. That is why
        always do our best to ensure the conditions related to each deal are as
        clear as possible. That being said, we rely on you, the customer, to
        choose carefully and ensure that the deal you select suits your needs,
        requirements, timing and redemption ability. If you decide over time
        that your Cobone voucher is no longer of interest we suggest you share
        some group buying love and gift it to a friend or family member. We
        value your business, and whilst we aren’t responsible for the quality of
        the service provided by the merchant or the experience itself, we will
        do everything we can to act as a liaison that can assist to find the
        most favourable outcome for you. So, if something major has let you down
        Contact Us and we’ll do all we can to make things right. Please note
        that refunds are not applicable in the following cases:
      </p>
      <p class="subtitle-1 font-weight-bold">
        - If your Cobone voucher has expired
      </p>
      <p class="subtitle-1 font-weight-bold">
        - If your Cobone voucher has expired
      </p>
      <p class="subtitle-1 font-weight-bold">
        - If your Cobone voucher has expired
      </p>
      <p class="subtitle-1 font-weight-bold">
        - If your Cobone voucher has expired
      </p>
    </v-container>
  </v-app>
</template>

<script>
export default {}
</script>

<style></style>
