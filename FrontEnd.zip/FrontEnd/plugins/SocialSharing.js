import Vue from 'vue'
var SocialSharing = require('vue-social-sharing')

Vue.use(SocialSharing)
